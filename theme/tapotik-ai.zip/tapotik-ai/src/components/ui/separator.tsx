"use client";

import * as React from "react";
import { Separator as SeparatorPrimitive } from "@base-ui/react/separator";

import { cn } from "@/lib/utils";

function Separator({
    className,
    orientation = "horizontal",
    decorative,
    ...props
}: React.ComponentProps<typeof SeparatorPrimitive> & {
    decorative?: boolean;
}) {
    // Base UI separators are always decorative; kept for shadcn API parity.
    void decorative;

    return (
        <SeparatorPrimitive
            data-slot="separator"
            orientation={orientation}
            className={cn(
                "shrink-0 bg-border data-[orientation=horizontal]:h-px data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-px",
                className,
            )}
            {...props}
        />
    );
}

export { Separator };
